package com.example.stopwatch;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.SharedValues;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    boolean ActiveState = false;
    int Count;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if(savedInstanceState != null){
            Count = savedInstanceState.getInt("TimeCount");
            ActiveState = savedInstanceState.getBoolean("WasActive");
        }
        else  {
            SharedPreferences sharedvalues = getApplicationContext().getSharedPreferences("TimerValues" ,0);
            Count = sharedvalues.getInt("time", 0);
            ActiveState = sharedvalues.getBoolean("active", false);
        }
        TextView Counter = findViewById(R.id.licznik);
        RunTimer();
    }
    public void StartCount(View view){
         ActiveState = true;
        Log.d("MainValues",String.valueOf(ActiveState));
        TextView BooleanStatus = findViewById(R.id.textView);
        BooleanStatus.setText(toString().valueOf(ActiveState));
        Toast.makeText(this, "Boolean True", Toast.LENGTH_SHORT).show();
    }
    public void StopCount(View view){
        ActiveState = false;
        Log.d("MainValues",String.valueOf(ActiveState));
        TextView BooleanStatus = findViewById(R.id.textView);
        BooleanStatus.setText(toString().valueOf(ActiveState));
        Toast.makeText(this, "Boolean Fales", Toast.LENGTH_SHORT).show();
    }
    public void ResetCount(View view){
        ActiveState = false;
        Log.d("MainValues",String.valueOf(ActiveState));
        TextView BooleanStatus = findViewById(R.id.textView);
        BooleanStatus.setText(toString().valueOf(ActiveState));
        Toast.makeText(this, "Boolean False", Toast.LENGTH_SHORT).show();
        Count = 0;
        TextView Counter = findViewById(R.id.licznik);
        Counter.setText(toString().valueOf(Count));
    }
    public void RunTimer(){
        final Handler Handler = new Handler();
        Handler.post(new Runnable() {
            @Override
            public void run() {
                Handler.postDelayed(this,1000);
                if (ActiveState == true){
                    TextView Counter = findViewById(R.id.licznik);
                    Counter.setText(toString().valueOf(Count));
                    Count++;

                }
                else if(ActiveState == false){
                    TextView Counter = findViewById(R.id.licznik);
                    Counter.setText(toString().valueOf(Count));
                }

            }
        });
    }
    @Override
    public void onSaveInstanceState(Bundle savedInstanceState){
        super.onSaveInstanceState(savedInstanceState);

        SharedPreferences sharedprefs = getApplicationContext().getSharedPreferences("TimerValues", 0);
        SharedPreferences.Editor SharedEditor = sharedprefs.edit();
        savedInstanceState.putInt("TimeCount",Count);
        savedInstanceState.putBoolean("WasActive",ActiveState);
        SharedEditor.putBoolean("active",ActiveState);
        SharedEditor.putInt("time", Count);
        SharedEditor.apply();
    }
}